# This is a calculator that calculates the salary of quarterbacks.
